# BnB Tonic Android APK

Packages the locked master BnB Tonic web app as an Android app. GitHub Actions builds the APK.
