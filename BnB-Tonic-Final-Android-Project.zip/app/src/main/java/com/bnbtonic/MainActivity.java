package com.bnbtonic;
import android.app.*; import android.os.*; import android.webkit.*; import android.net.Uri; import android.content.*;
public class MainActivity extends Activity {
 WebView web; ValueCallback<Uri[]> fileCallback;
 public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
 web.setWebChromeClient(new WebChromeClient(){public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;startActivityForResult(p.createIntent(),42);return true;}});
 web.loadUrl("file:///android_asset/index.html"); setContentView(web);}
 protected void onActivityResult(int r,int c,Intent d){if(r==42&&fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d));fileCallback=null;}super.onActivityResult(r,c,d);}
}