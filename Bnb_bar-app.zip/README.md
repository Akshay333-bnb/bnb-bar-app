# Barefoot & Beyond Bar Inventory — Android v2

Features:
- Dashboard with sales, purchases, stock and gross profit
- Inventory management
- Purchase price and selling price fields start empty
- Edit/delete products, purchases and orders
- Sales/order tracking with stock deduction
- Stock adjustments for breakage, wastage, complimentary stock, etc.
- Low-stock alerts
- CSV downloads for sales, inventory and purchases
- PDF profit report
- Barefoot & Beyond logo in the app header and launcher icon

Seeded products:
Bud Magnum, Bud Premium, Corona, Tuborg, Carlsberg, Kingfisher Premium,
Kingfisher Strong, UB Strong, Breezer, Buzzball.

Build:
Open with Android Studio or use the included GitHub Actions workflow.


## Version 2.1 price update
Default selling rates configured for the bar inventory:
- Bud Magnum ₹300
- Bud Premium ₹250
- Corona ₹250
- Tuborg ₹250
- Carlsberg ₹290
- Kingfisher Premium ₹200
- Kingfisher Strong ₹250
- UB Strong ₹250
- Breezer ₹200
- Buzzball ₹180

Existing saved products are migrated to these selling rates on app launch, and UB Strong is added automatically if missing. New sales orders pre-fill the selected product's configured selling price.
