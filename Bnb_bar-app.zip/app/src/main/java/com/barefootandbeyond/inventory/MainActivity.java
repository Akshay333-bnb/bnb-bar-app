package com.barefootandbeyond.inventory;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    final ArrayList<Product> products = new ArrayList<>();
    final ArrayList<Purchase> purchases = new ArrayList<>();
    final ArrayList<Order> orders = new ArrayList<>();
    final ArrayList<Adjustment> adjustments = new ArrayList<>();
    android.content.SharedPreferences prefs;
    final SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

    int terracotta = Color.rgb(139,63,34);
    int sunset = Color.rgb(216,137,32);
    int cream = Color.rgb(246,217,138);
    int dark = Color.rgb(36,21,15);
    int card = Color.rgb(255,248,234);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("bnb_data", MODE_PRIVATE);
        loadData();
        if (products.isEmpty()) seedProducts();
        applyDefaultSellingRates();
        buildShell();
        showDashboard();
    }

    void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(250,244,234));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(16,10,16,10);
        GradientDrawable hg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{dark, terracotta, sunset});
        header.setBackground(hg);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.barefootandbeyond.inventory.R.drawable.bnb_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo, new LinearLayout.LayoutParams(72,72));

        TextView title = new TextView(this);
        title.setText("  BAREFOOT & BEYOND\n  BAR INVENTORY");
        title.setTextColor(cream);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        root.addView(header);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(4,4,4,4);
        nav.setBackgroundColor(dark);
        String[] labels = {"Dashboard","Inventory","Purchases","Orders","Reports"};
        for (String s: labels) {
            Button x = navButton(s);
            nav.addView(x, new LinearLayout.LayoutParams(0,56,1));
        }
        root.addView(nav);
    }

    Button navButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setTextColor(cream);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setOnClickListener(v -> {
            if(text.equals("Dashboard")) showDashboard();
            else if(text.equals("Inventory")) showInventory();
            else if(text.equals("Purchases")) showPurchases();
            else if(text.equals("Orders")) showOrders();
            else showReports();
        });
        return b;
    }

    void clear(String heading) {
        content.removeAllViews();
        TextView h = new TextView(this);
        h.setText(heading);
        h.setTextColor(dark);
        h.setTextSize(25);
        h.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        h.setPadding(16,18,16,12);
        content.addView(h);
    }

    TextView tv(String text, float size, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(14,8,14,8);
        return t;
    }

    Button action(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(terracotta);
        g.setCornerRadius(18);
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout cardLayout() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(12,10,12,10);
        GradientDrawable g = new GradientDrawable();
        g.setColor(card); g.setCornerRadius(22); g.setStroke(1, Color.rgb(225,207,183));
        c.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(12,6,12,6);
        c.setLayoutParams(p);
        return c;
    }

    void showDashboard() {
        clear("Dashboard");
        double sales = totalSales(), profit = totalProfit(), purchasesTotal = totalPurchases();
        int stock = totalStock();
        LinearLayout grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        addMetric(grid,"TODAY / TOTAL SALES","₹"+money(sales));
        addMetric(grid,"PURCHASE VALUE","₹"+money(purchasesTotal));
        addMetric(grid,"CURRENT STOCK UNITS",""+stock);
        addMetric(grid,"GROSS PROFIT","₹"+money(profit));
        content.addView(grid);

        LinearLayout low = cardLayout();
        low.addView(tv("LOW STOCK",18,terracotta));
        boolean any=false;
        for(Product p:products) if(stockFor(p.id)<=p.lowStock) {
            any=true; low.addView(tv(p.name+" — "+stockFor(p.id)+" left",15,dark));
        }
        if(!any) low.addView(tv("No low-stock items.",14,Color.DKGRAY));
        content.addView(low);

        LinearLayout quick = cardLayout();
        quick.addView(tv("QUICK ACTIONS",18,terracotta));
        quick.addView(action("＋ Add Purchase",v->purchaseDialog(-1)));
        quick.addView(action("＋ Add Order",v->orderDialog(-1)));
        quick.addView(action("＋ Stock Adjustment",v->adjustmentDialog()));
        content.addView(quick);
    }

    void addMetric(LinearLayout parent, String label, String value) {
        LinearLayout c=cardLayout();
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView a=tv(label,13,Color.DKGRAY); row.addView(a,new LinearLayout.LayoutParams(0,-2,1));
        TextView b=tv(value,22,dark); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); row.addView(b);
        c.addView(row); parent.addView(c);
    }

    void showInventory() {
        clear("Inventory");
        content.addView(action("＋ Add New Product",v->productDialog(-1)));
        for(Product p:products) {
            LinearLayout c=cardLayout();
            c.addView(tv(p.name+"  •  "+p.category,18,dark));
            String buy=p.buy<=0?"—":"₹"+money(p.buy);
            String sell=p.sell<=0?"—":"₹"+money(p.sell);
            double prof=(p.buy>0&&p.sell>0)?p.sell-p.buy:0;
            c.addView(tv("Stock: "+stockFor(p.id)+"    Buy: "+buy+"    Sell: "+sell+
                    "\nUnit Profit: "+(prof>0?"₹"+money(prof):"—")+
                    "    Margin: "+(p.sell>0&&p.buy>0?String.format(Locale.getDefault(),"%.1f%%",prof/p.sell*100):"—"),14,Color.DKGRAY));
            LinearLayout row=new LinearLayout(this);
            Button edit=action("Edit",v->productDialog(p.id)); row.addView(edit,new LinearLayout.LayoutParams(0,52,1));
            Button del=action("Delete",v->deleteProduct(p.id)); row.addView(del,new LinearLayout.LayoutParams(0,52,1));
            c.addView(row); content.addView(c);
        }
    }

    void showPurchases() {
        clear("Purchases");
        content.addView(action("＋ Add Purchase",v->purchaseDialog(-1)));
        if(purchases.isEmpty()) content.addView(tv("No purchases yet.",16,Color.DKGRAY));
        for(int i=0;i<purchases.size();i++) {
            Purchase x=purchases.get(i); Product p=findProduct(x.productId);
            LinearLayout c=cardLayout();
            c.addView(tv(df.format(new Date(x.date))+"  •  "+(p==null?"Deleted product":p.name),17,dark));
            c.addView(tv("Qty: "+x.qty+"   Unit cost: ₹"+money(x.unitCost)+"   Total: ₹"+money(x.qty*x.unitCost)+
                    "\nSupplier: "+safe(x.supplier)+"   Ref: "+safe(x.ref),14,Color.DKGRAY));
            LinearLayout row=new LinearLayout(this);
            row.addView(action("Edit",v->purchaseDialog(i)),new LinearLayout.LayoutParams(0,52,1));
            row.addView(action("Delete",v->deletePurchase(i)),new LinearLayout.LayoutParams(0,52,1));
            c.addView(row); content.addView(c);
        }
    }

    void showOrders() {
        clear("Orders / Sales");
        content.addView(action("＋ Add Order",v->orderDialog(-1)));
        if(orders.isEmpty()) content.addView(tv("No orders yet.",16,Color.DKGRAY));
        for(int i=0;i<orders.size();i++) {
            Order x=orders.get(i); Product p=findProduct(x.productId);
            LinearLayout c=cardLayout();
            c.addView(tv("Order #"+x.number+"  •  "+df.format(new Date(x.date)),17,dark));
            double rev=x.qty*x.sellAt, cost=x.qty*x.costAt, pr=rev-cost;
            c.addView(tv((p==null?"Deleted product":p.name)+" × "+x.qty+
                    "\nRevenue: ₹"+money(rev)+"   Cost: ₹"+money(cost)+"   Profit: ₹"+money(pr)+
                    "\nCustomer/Note: "+safe(x.note),14,Color.DKGRAY));
            LinearLayout row=new LinearLayout(this);
            row.addView(action("Edit",v->orderDialog(i)),new LinearLayout.LayoutParams(0,52,1));
            row.addView(action("Delete",v->deleteOrder(i)),new LinearLayout.LayoutParams(0,52,1));
            c.addView(row); content.addView(c);
        }
    }

    void showReports() {
        clear("Reports & Downloads");
        LinearLayout c=cardLayout();
        c.addView(tv("Download your bar reports",19,dark));
        c.addView(action("Download Sales CSV",v->exportCsv("sales")));
        c.addView(action("Download Inventory CSV",v->exportCsv("inventory")));
        c.addView(action("Download Purchases CSV",v->exportCsv("purchases")));
        c.addView(action("Download Profit PDF",v->exportPdf()));
        content.addView(c);

        LinearLayout summary=cardLayout();
        summary.addView(tv("Summary",19,terracotta));
        summary.addView(tv("Sales: ₹"+money(totalSales())+
                "\nPurchases: ₹"+money(totalPurchases())+
                "\nGross Profit: ₹"+money(totalProfit())+
                "\nOrders: "+orders.size()+
                "\nStock Units: "+totalStock(),15,dark));
        content.addView(summary);
    }

    void productDialog(int idx) {
        Product p = idx<0?null:findProduct(idx);
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(18,5,18,5);
        EditText name=field("Product name",p==null?"":p.name);
        EditText cat=field("Category",p==null?"Beer":p.category);
        EditText buy=field("Purchase price / unit (optional)",p==null?"":num(p.buy));
        EditText sell=field("Selling price / unit (optional)",p==null?"":num(p.sell));
        EditText opening=field("Opening stock",p==null?"0":""+p.opening);
        EditText low=field("Low stock alert at",p==null?"5":""+p.lowStock);
        form.addView(name);form.addView(cat);form.addView(buy);form.addView(sell);form.addView(opening);form.addView(low);
        new AlertDialog.Builder(this).setTitle(p==null?"Add Product":"Edit Product").setView(form)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                try {
                    if(p==null) { Product q=new Product(); q.id=nextId(); q.name=name.getText().toString(); q.category=cat.getText().toString(); q.buy=parseD(buy); q.sell=parseD(sell); q.opening=parseI(opening); q.lowStock=parseI(low); products.add(q); }
                    else { p.name=name.getText().toString(); p.category=cat.getText().toString(); p.buy=parseD(buy); p.sell=parseD(sell); p.opening=parseI(opening); p.lowStock=parseI(low); }
                    saveData(); showInventory();
                } catch(Exception e){toast("Please check the values.");}
            }).show();
    }

    void purchaseDialog(int idx) {
        Purchase x=idx<0?null:purchases.get(idx);
        LinearLayout form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL);
        Spinner prod=spinner(); ArrayList<String> names=new ArrayList<>(); for(Product p:products) names.add(p.name);
        prod.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        if(x!=null) prod.setSelection(Math.max(0,indexOfProduct(x.productId)));
        EditText qty=field("Quantity",x==null?"":""+x.qty);
        EditText cost=field("Purchase price / unit",x==null?"":num(x.unitCost));
        EditText supplier=field("Supplier",x==null?"":x.supplier);
        EditText ref=field("Invoice / reference",x==null?"":x.ref);
        form.addView(prod);form.addView(qty);form.addView(cost);form.addView(supplier);form.addView(ref);
        new AlertDialog.Builder(this).setTitle(x==null?"Add Purchase":"Edit Purchase").setView(form)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                try {
                    Product p=products.get(prod.getSelectedItemPosition());
                    if(x==null){x=new Purchase();x.id=nextId();purchases.add(x);}
                    x.productId=p.id;x.qty=parseI(qty);x.unitCost=parseD(cost);x.supplier=supplier.getText().toString();x.ref=ref.getText().toString();x.date=System.currentTimeMillis();
                    // Keep the product's displayed purchase price updated to the latest manually entered purchase rate.
                    p.buy=x.unitCost;
                    saveData();showPurchases();
                }catch(Exception e){toast("Please check the values.");}
            }).show();
    }

    void orderDialog(int idx) {
        Order x=idx<0?null:orders.get(idx);
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        Spinner prod=spinner();ArrayList<String> names=new ArrayList<>();for(Product p:products)names.add(p.name);
        prod.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        if(x!=null)prod.setSelection(Math.max(0,indexOfProduct(x.productId)));
        EditText qty=field("Quantity sold",x==null?"":""+x.qty);
        double defaultSell = products.isEmpty()?0:products.get(0).sell;
        double defaultCost = products.isEmpty()?0:products.get(0).buy;
        EditText sell=field("Selling price / unit",x==null?num(defaultSell):num(x.sellAt));
        EditText cost=field("Purchase cost / unit",x==null?num(defaultCost):num(x.costAt));
        EditText note=field("Customer / note",x==null?"":x.note);
        form.addView(prod);form.addView(qty);form.addView(sell);form.addView(cost);form.addView(note);
        prod.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (x==null && position>=0 && position<products.size()) {
                    Product selected=products.get(position);
                    sell.setText(num(selected.sell));
                    cost.setText(num(selected.buy));
                }
            }
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        new AlertDialog.Builder(this).setTitle(x==null?"Add Order":"Edit Order").setView(form)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                try{
                    Product p=products.get(prod.getSelectedItemPosition());
                    int newQty=parseI(qty);
                    // Prevent negative stock when creating/editing.
                    int oldQty=(x==null?0:x.qty);
                    int available=stockFor(p.id)+oldQty;
                    if(newQty>available){toast("Not enough stock. Available: "+available);return;}
                    if(x==null){x=new Order();x.id=nextId();x.number=nextOrderNumber();orders.add(x);}
                    x.productId=p.id;x.qty=newQty;x.sellAt=parseD(sell);x.costAt=parseD(cost);x.note=note.getText().toString();x.date=System.currentTimeMillis();
                    if(x.sellAt>0)p.sell=x.sellAt;
                    saveData();showOrders();
                }catch(Exception e){toast("Please check the values.");}
            }).show();
    }

    void adjustmentDialog() {
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        Spinner prod=spinner();ArrayList<String> names=new ArrayList<>();for(Product p:products)names.add(p.name);
        prod.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        EditText qty=field("Adjustment (+ received / - breakage / wastage)", "");
        EditText note=field("Reason", "");
        form.addView(prod);form.addView(qty);form.addView(note);
        new AlertDialog.Builder(this).setTitle("Stock Adjustment").setView(form)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                try{Adjustment a=new Adjustment();a.id=nextId();a.productId=products.get(prod.getSelectedItemPosition()).id;a.qty=parseI(qty);a.note=note.getText().toString();a.date=System.currentTimeMillis();adjustments.add(a);saveData();showDashboard();}
                catch(Exception e){toast("Please check the values.");}
            }).show();
    }

    EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextSize(15);e.setSingleLine(true);e.setPadding(8,8,8,8);return e;}
    Spinner spinner(){Spinner s=new Spinner(this);s.setPadding(8,8,8,8);return s;}

    void deleteProduct(int id){new AlertDialog.Builder(this).setTitle("Delete product?").setMessage("Historical entries remain, but this product will disappear from inventory.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{products.removeIf(p->p.id==id);saveData();showInventory();}).show();}
    void deletePurchase(int i){new AlertDialog.Builder(this).setTitle("Delete purchase?").setMessage("This will reduce recorded stock by that purchase quantity.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{purchases.remove(i);saveData();showPurchases();}).show();}
    void deleteOrder(int i){new AlertDialog.Builder(this).setTitle("Delete order?").setMessage("Stock sold in this order will be returned to inventory.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{orders.remove(i);saveData();showOrders();}).show();}

    int stockFor(int id){int n=0;Product p=findProduct(id);if(p!=null)n+=p.opening;for(Purchase x:purchases)if(x.productId==id)n+=x.qty;for(Order x:orders)if(x.productId==id)n-=x.qty;for(Adjustment x:adjustments)if(x.productId==id)n+=x.qty;return n;}
    int totalStock(){int n=0;for(Product p:products)n+=Math.max(0,stockFor(p.id));return n;}
    double totalSales(){double n=0;for(Order x:orders)n+=x.qty*x.sellAt;return n;}
    double totalProfit(){double n=0;for(Order x:orders)n+=x.qty*(x.sellAt-x.costAt);return n;}
    double totalPurchases(){double n=0;for(Purchase x:purchases)n+=x.qty*x.unitCost;return n;}
    Product findProduct(int id){for(Product p:products)if(p.id==id)return p;return null;}
    int indexOfProduct(int id){for(int i=0;i<products.size();i++)if(products.get(i).id==id)return i;return 0;}
    int nextId(){int m=0;for(Product p:products)m=Math.max(m,p.id);for(Purchase x:purchases)m=Math.max(m,x.id);for(Order x:orders)m=Math.max(m,x.id);for(Adjustment x:adjustments)m=Math.max(m,x.id);return m+1;}
    int nextOrderNumber(){int m=1000;for(Order x:orders)m=Math.max(m,x.number);return m+1;}
    double parseD(EditText e){String s=e.getText().toString().trim();return s.isEmpty()?0:Double.parseDouble(s);}
    int parseI(EditText e){String s=e.getText().toString().trim();return s.isEmpty()?0:Integer.parseInt(s);}
    String num(double d){return d<=0?"":String.valueOf(d);}
    String money(double d){return String.format(Locale.getDefault(),"%.2f",d);}
    String safe(String s){return s==null||s.isEmpty()?"—":s;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void exportCsv(String type){
        StringBuilder sb=new StringBuilder();
        if(type.equals("sales")){
            sb.append("Date,Order,Product,Qty,Selling Price,Purchase Cost,Revenue,Profit,Note\n");
            for(Order x:orders){Product p=findProduct(x.productId);sb.append(df.format(new Date(x.date))).append(",").append(x.number).append(",")
            .append(csv(p==null?"Deleted":p.name)).append(",").append(x.qty).append(",").append(x.sellAt).append(",").append(x.costAt).append(",")
            .append(x.qty*x.sellAt).append(",").append(x.qty*(x.sellAt-x.costAt)).append(",").append(csv(x.note)).append("\n");}
        } else if(type.equals("purchases")){
            sb.append("Date,Product,Qty,Purchase Price,Total,Supplier,Reference\n");
            for(Purchase x:purchases){Product p=findProduct(x.productId);sb.append(df.format(new Date(x.date))).append(",").append(csv(p==null?"Deleted":p.name)).append(",")
            .append(x.qty).append(",").append(x.unitCost).append(",").append(x.qty*x.unitCost).append(",").append(csv(x.supplier)).append(",").append(csv(x.ref)).append("\n");}
        } else {
            sb.append("Product,Category,Opening,Purchases,Sales,Adjustments,Current Stock,Purchase Price,Selling Price,Unit Profit\n");
            for(Product p:products){int pur=0,sal=0,adj=0;for(Purchase x:purchases)if(x.productId==p.id)pur+=x.qty;for(Order x:orders)if(x.productId==p.id)sal+=x.qty;for(Adjustment x:adjustments)if(x.productId==p.id)adj+=x.qty;
            sb.append(csv(p.name)).append(",").append(csv(p.category)).append(",").append(p.opening).append(",").append(pur).append(",").append(sal).append(",").append(adj).append(",").append(stockFor(p.id)).append(",").append(p.buy).append(",").append(p.sell).append(",").append((p.sell>0&&p.buy>0)?p.sell-p.buy:0).append("\n");}
        }
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"bnb_"+type+"_"+new SimpleDateFormat("yyyyMMdd_HHmm",Locale.getDefault()).format(new Date())+".csv");
        pendingContent=sb.toString();startActivityForResult(i,10);
    }
    String pendingContent="";
    void exportPdf(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,"bnb_profit_report_"+new SimpleDateFormat("yyyyMMdd_HHmm",Locale.getDefault()).format(new Date())+".pdf");
        pendingPdf=true;startActivityForResult(i,11);
    }
    boolean pendingPdf=false;
    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data);if(c!=RESULT_OK||data==null)return;
        try{
            OutputStream os=getContentResolver().openOutputStream(data.getData());
            if(r==10){os.write(pendingContent.getBytes("UTF-8"));os.close();toast("CSV report saved.");}
            else if(r==11){android.graphics.pdf.PdfDocument doc=new android.graphics.pdf.PdfDocument();android.graphics.pdf.PdfDocument.PageInfo pi=new android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,1).create();android.graphics.pdf.PdfDocument.Page pg=doc.startPage(pi);android.graphics.Canvas c2=pg.getCanvas();android.graphics.Paint paint=new android.graphics.Paint();paint.setColor(dark);paint.setTextSize(18);float y=40;c2.drawText("BAREFOOT & BEYOND — BAR PROFIT REPORT",20,y,paint);paint.setTextSize(13);y+=35;c2.drawText("Sales: ₹"+money(totalSales()),20,y,paint);y+=22;c2.drawText("Purchases: ₹"+money(totalPurchases()),20,y,paint);y+=22;c2.drawText("Gross Profit: ₹"+money(totalProfit()),20,y,paint);y+=22;c2.drawText("Orders: "+orders.size(),20,y,paint);y+=30;for(Order x:orders){Product p=findProduct(x.productId);String line=df.format(new Date(x.date))+"  #"+x.number+"  "+(p==null?"Deleted":p.name)+" ×"+x.qty+"  Profit ₹"+money(x.qty*(x.sellAt-x.costAt));if(y>810){doc.finishPage(pg);pi=new android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,1).create();pg=doc.startPage(pi);c2=pg.getCanvas();y=40;}c2.drawText(line,20,y,paint);y+=18;}doc.finishPage(pg);doc.writeTo(os);doc.close();toast("PDF report saved.");}
        }catch(Exception e){toast("Could not save report.");}
        pendingContent="";pendingPdf=false;
    }
    String csv(String s){return "\""+(s==null?"":s.replace("\"","\"\""))+"\"";}

    void seedProducts(){
        String[] names={"Bud Magnum","Bud Premium","Corona","Tuborg","Carlsberg","Kingfisher Premium","Kingfisher Strong","UB Strong","Breezer","Buzzball"};
        double[] sellRates={300,250,250,250,290,200,250,250,200,180};
        for(int i=0;i<names.length;i++){
            Product p=new Product();
            p.id=products.size()+1;
            p.name=names[i];
            p.category=names[i].equals("Breezer")||names[i].equals("Buzzball")?"RTD":"Beer";
            p.buy=0;
            p.sell=sellRates[i];
            p.opening=0;
            p.lowStock=5;
            products.add(p);
        }
        saveData();
    }

    void applyDefaultSellingRates(){
        String[] names={"Bud Magnum","Bud Premium","Corona","Tuborg","Carlsberg","Kingfisher Premium","Kingfisher Strong","UB Strong","Breezer","Buzzball"};
        double[] sellRates={300,250,250,250,290,200,250,250,200,180};
        boolean changed=false;
        for(int i=0;i<names.length;i++){
            for(Product p:products){
                if(p.name.equalsIgnoreCase(names[i])){
                    if(p.sell!=sellRates[i]){p.sell=sellRates[i];changed=true;}
                }
            }
        }
        // Add UB Strong automatically if an older saved version did not contain it.
        if(findProductByName("UB Strong")==null){
            Product p=new Product();
            p.id=nextId();
            p.name="UB Strong";
            p.category="Beer";
            p.buy=0;
            p.sell=250;
            p.opening=0;
            p.lowStock=5;
            products.add(p);
            changed=true;
        }
        if(changed) saveData();
    }

    Product findProductByName(String name){
        for(Product p:products) if(p.name.equalsIgnoreCase(name)) return p;
        return null;
    }

    void saveData(){
        try{
            JSONArray a=new JSONArray();for(Product p:products){JSONObject o=new JSONObject();o.put("id",p.id);o.put("name",p.name);o.put("cat",p.category);o.put("buy",p.buy);o.put("sell",p.sell);o.put("opening",p.opening);o.put("low",p.lowStock);a.put(o);}prefs.edit().putString("products",a.toString()).apply();
            a=new JSONArray();for(Purchase x:purchases){JSONObject o=new JSONObject();o.put("id",x.id);o.put("pid",x.productId);o.put("qty",x.qty);o.put("cost",x.unitCost);o.put("supplier",x.supplier);o.put("ref",x.ref);o.put("date",x.date);a.put(o);}prefs.edit().putString("purchases",a.toString()).apply();
            a=new JSONArray();for(Order x:orders){JSONObject o=new JSONObject();o.put("id",x.id);o.put("num",x.number);o.put("pid",x.productId);o.put("qty",x.qty);o.put("sell",x.sellAt);o.put("cost",x.costAt);o.put("note",x.note);o.put("date",x.date);a.put(o);}prefs.edit().putString("orders",a.toString()).apply();
            a=new JSONArray();for(Adjustment x:adjustments){JSONObject o=new JSONObject();o.put("id",x.id);o.put("pid",x.productId);o.put("qty",x.qty);o.put("note",x.note);o.put("date",x.date);a.put(o);}prefs.edit().putString("adjustments",a.toString()).apply();
        }catch(Exception ignored){}
    }

    void loadData(){
        try{
            JSONArray a=new JSONArray(prefs.getString("products","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Product p=new Product();p.id=o.getInt("id");p.name=o.getString("name");p.category=o.getString("cat");p.buy=o.optDouble("buy");p.sell=o.optDouble("sell");p.opening=o.optInt("opening");p.lowStock=o.optInt("low",5);products.add(p);}
            a=new JSONArray(prefs.getString("purchases","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Purchase x=new Purchase();x.id=o.getInt("id");x.productId=o.getInt("pid");x.qty=o.getInt("qty");x.unitCost=o.optDouble("cost");x.supplier=o.optString("supplier");x.ref=o.optString("ref");x.date=o.optLong("date",System.currentTimeMillis());purchases.add(x);}
            a=new JSONArray(prefs.getString("orders","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Order x=new Order();x.id=o.getInt("id");x.number=o.getInt("num");x.productId=o.getInt("pid");x.qty=o.getInt("qty");x.sellAt=o.optDouble("sell");x.costAt=o.optDouble("cost");x.note=o.optString("note");x.date=o.optLong("date",System.currentTimeMillis());orders.add(x);}
            a=new JSONArray(prefs.getString("adjustments","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Adjustment x=new Adjustment();x.id=o.getInt("id");x.productId=o.getInt("pid");x.qty=o.getInt("qty");x.note=o.optString("note");x.date=o.optLong("date",System.currentTimeMillis());adjustments.add(x);}
        }catch(Exception ignored){}
    }

    static class Product {int id,opening,lowStock;String name="",category="";double buy,sell;}
    static class Purchase {int id,productId,qty;String supplier="",ref="";double unitCost;long date;}
    static class Order {int id,number,productId,qty;String note="";double sellAt,costAt;long date;}
    static class Adjustment {int id,productId,qty;String note="";long date;}
}
