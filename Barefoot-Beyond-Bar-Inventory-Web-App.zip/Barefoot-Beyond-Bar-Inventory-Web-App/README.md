# Barefoot & Beyond Bar Inventory
Standalone mobile-friendly offline bar inventory app.

Includes dashboard, inventory, purchases, sales/orders, profit, low-stock alerts, edit/delete, JSON backup and CSV reports.

Preloaded selling rates:
Bud Magnum ₹300; Bud Premium ₹250; Corona ₹250; Tuborg ₹250; Carlsberg ₹290; Kingfisher Premium ₹200; Kingfisher Strong ₹250; UB Strong ₹250; Breezer ₹200; BuzzBall ₹180.

Purchase prices start unset and can be entered later. New beers can be added or deleted from Inventory.
